package org.example.eyecareproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EyecareProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
