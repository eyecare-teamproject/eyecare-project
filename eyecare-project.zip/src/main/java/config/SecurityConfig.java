package config;

public class SecurityConfig {
}
